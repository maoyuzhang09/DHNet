blocks<-function(n1,n2,p,symm=0){
  if(symm==0){
    A<-matrix(sample(c(0,1),n1*n2,prob=c(1-p,p),replace=TRUE),nrow=n1,ncol=n2)
  }
  if(symm==1){
    A<-matrix(0,n1,n2)
    for(i in 1:n1){
      A[i,]=A[,i]=sample(c(0,1),n1,prob=c(1-p,p),replace=TRUE)
    }
  }
  A
}

generateA<-function(n1=100,n2=50,p1=0.1,p2=0.2,p3=0.05,r1=0,r2=0,r3=0.1){
p<-matrix(0,6,6)
p[1,]<-c(p1+r1,p1,p1,p3+r3,p3,p3)
p[2,]<-c(p1,p1+r1,p1,p3,p3+r3,p3)
p[3,]<-c(p1,p1,p1+r1,p3,p3,p3+r3)
p[4,]<-c(p3+r3,p3,p3,p2+r2,p2,p2)
p[5,]<-c(p3,p3+r3,p3,p2,p2+r2,p2)
p[6,]<-c(p3,p3,p3+r3,p2,p2,p2+r2)
A11<-blocks(n1,n1,p[1,1],1)
A12<-blocks(n1,n1,p[1,2],0)
A13<-blocks(n1,n1,p[1,3],0)
A14<-blocks(n1,n2,p[1,4],0)
A15<-blocks(n1,n2,p[1,5],0)
A16<-blocks(n1,n2,p[1,6],0)
A21<-t(A12)
A22<-blocks(n1,n1,p[2,2],1)
A23<-blocks(n1,n1,p[2,3],0)
A24<-blocks(n1,n2,p[2,4],0)   
A25<-blocks(n1,n2,p[2,5],0)
A26<-blocks(n1,n2,p[2,6],0)
A31<-t(A13)
A32<-t(A23)
A33<-blocks(n1,n1,p[3,3],1)
A34<-blocks(n1,n2,p[3,4],0) 
A35<-blocks(n1,n2,p[3,5],0)
A36<-blocks(n1,n2,p[3,6],0)
A41<-t(A14)
A42<-t(A24)
A43<-t(A34)
A44<-blocks(n2,n2,p[4,4],1)
A45<-blocks(n2,n2,p[4,5],0)
A46<-blocks(n2,n2,p[4,6],0)
A51<-t(A15)
A52<-t(A25)
A53<-t(A35)
A54<-t(A45)
A55<-blocks(n2,n2,p[5,5],1)
A56<-blocks(n2,n2,p[5,6],0)
A61<-t(A16)
A62<-t(A26)
A63<-t(A36)
A64<-t(A46)
A65<-t(A56)
A66<-blocks(n2,n2,p[6,6],1)
A<-rbind(cbind(A11,A12,A13,A14,A15,A16),cbind(A21,A22,A23,A24,A25,A26),cbind(A31,A32,A33,A34,A35,A36),cbind(A41,A42,A43,A44,A45,A46),cbind(A51,A52,A53,A54,A55,A56),cbind(A61,A62,A63,A64,A65,A66))   
diag(A)<-0
A
}



#set this to the downloaded 'Rtoolbox/data_example'
setwd('/Users/code/Rtoolbox/data_example')                            #set this to the downloaded 'Rtoolbox/data_example'
for(i in 1:20){
  A<-generateA(n1=200,n2=100,p1=0.5,p2=0.6,p3=0.3,r1=0,r2=0,r3=0.1)
  write.table(A,paste("A",i,".csv",sep=""),sep=",",row.names=FALSE,col.names=FALSE)	
}
