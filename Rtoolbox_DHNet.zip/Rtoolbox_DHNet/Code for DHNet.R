
###change the Working Directory to the path of the downloaded 'Rtoolbox' file:
## setwd("the path of the downloaded 'Rtoolbox' file")

###


library(matlabr)      #the following code requires R package 'matlabr'
library(igraph)       #the following code requires R pacakge 'igraph'
#set up the path for matlab, i.e. where the file "matlab.exe" is located
options(matlab.path = "/Applications/MATLAB_R2020b.app/bin") 
have_matlab()                                                  #this result indicates if matlab can be called
                                                               #the output should be TRUE

##read the related file and functions###
source('generateA.R')

####proposed method in the paper
#this function calculates the modularity matrix of the proposed method. Here size is the number of nodes in the network and n is the number of snapshots.
#n1 is the number of type1 node in each community, and n2 is the number of type2 node in each community. 
calculate_MMat<-function(size,n,n1,n2){                          
  M<-matrix(0,size,size)
  M11 <- M22 <- M33 <- M44 <- m11 <- m22 <- m44 <-0
  for(i in 1:n){
    A<-read.csv(paste("A",i,".csv",sep=""),header=F)
    A<-as.matrix(A)
    if(dim(A)[1]==size & dim(A)[2]==size){
      diag(A)<-0
      G<-graph.adjacency(A,mode="max")
      AA11<-get.adjacency(G,type="both",sparse=F)
      A1<-AA11[1:(3*n1),1:(3*n1)]###Note that 3 is the number of communities
      A2<-AA11[1:(3*n1),((3*n1)+1):(3*(n1+n2))]
      A3<-t(A2)
      A4<-AA11[((3*n1)+1):(3*(n1+n2)),((3*n1)+1):(3*(n1+n2))]
      d1<-apply(A1,2,sum)
      m1<-sum(d1)
      M1<-A1-(d1%*%t(d1))/m1
      row<-apply(A2,1,sum) ##X^Y
      col<-apply(A2,2,sum) ##Y^X 
      m2<-sum(row)
      M2<-A2-(row%*%t(col))/m2
      M3<-t(M2)
      diag(A4)=0
      d4<-apply(A4,2,sum)
      m4<-sum(d4)
      M4<-A4-(d4%*%t(d4))/m4
      M11<-M11+M1
      M22<-M22+M2
      M33<-M33+M3
      M44<-M44+M4
      m11<-m11+m1
      m22<-m22+m2
      m44<-m44+m4
    }
    else{
      print("networks are not the same size")
    }
  }
  M<- rbind(cbind(M11/m11,M22/m22),cbind(M33/m22,M44/m44))
  M
}


######Method 1 in the paper#####
calculate_MMat2<-function(size,n){                           #this function calculates the modularity matrix of Method 1 in the paper. Here size is the number of nodes in the network and n is the number of snapshots.
  M<-matrix(0,size,size)
  sum <- 0
  for(i in 1:n){
    A<-read.csv(paste("A",i,".csv",sep=""),header=F)
    A<-as.matrix(A)
    if(dim(A)[1]==size & dim(A)[2]==size){
      G<-graph.adjacency(A,mode="max")
      A<-get.adjacency(G,type="both",sparse=F)
      sum<-sum+sum(A)
      M<-M+(A-degree(G)%*%t(degree(G))/sum(degree(G)))
    }
    else{
      print("networks are not the same size")
    }
  }
  list(M=M,sum=sum)
}
  
#######Method 2 in the paper#######
calculate_MMat3<-function(size,n,n1,n2){             #this function calculates the modularity matrix of Methed 2. Here size is the number of nodes in the network and n is the number of snapshots.
  A11<-matrix(0,size,size)
  for(i in 1:n){
    A<-read.csv(paste("A",i,".csv",sep=""),header=F)
    A<-as.matrix(A)
    if(dim(A)[1]==size & dim(A)[2]==size){
      diag(A)<-0
      G<-graph.adjacency(A,mode="max")
      AA<-get.adjacency(G,type="both",sparse=F)
      A11<-A11+AA
    }
    else{
      print("networks are not the same size")
    }
  }
  G11<-graph.adjacency(A11,mode="undirected",weighted=TRUE)
  AA11<-as.matrix(as_adjacency_matrix(G11))
  diag(AA11)=0
  A1<-AA11[1:(3*n1),1:(3*n1)]###Note that 3 is the number of communities
  A2<-AA11[1:(3*n1),((3*n1)+1):(3*(n1+n2))]
  A3<-t(A2)
  A4<-AA11[((3*n1)+1):(3*(n1+n2)),((3*n1)+1):(3*(n1+n2))]
  d1<-apply(A1,2,sum)
  m1<-sum(d1)
  M1<-A1-(d1%*%t(d1))/m1
  row<-apply(A2,1,sum) ##X^Y
  col<-apply(A2,2,sum) ##Y^X 
  m2<-sum(row)
  M2<-A2-(row%*%t(col))/m2
  M3<-t(M2)
  diag(A4)=0
  d4<-apply(A4,2,sum)
  m4<-sum(d4)
  M4<-A4-(d4%*%t(d4))/m4
  M<-rbind(cbind(M1/m1,M2/m2),cbind(M3/m2,M4/m4))
  M
}

#####Method 3 in the paper ########
calculate_MMat4<-function(size,n,n1,n2){                           #this function calculates the modularity matrix of Methed 3. Here size is the number of nodes in the network and n is the number of snapshots.
  M<-matrix(0,size,size)
  i <- sample(1:n,1)
  A<-read.csv(paste("A",i,".csv",sep=""),header=F)
  A<-as.matrix(A)
  if(dim(A)[1]==size & dim(A)[2]==size){
      diag(A)<-0
      G<-graph.adjacency(A,mode="max")
      AA11<-get.adjacency(G,type="both",sparse=F)
      A1<-AA11[1:(3*n1),1:(3*n1)]###Note that 3 is the number of communities
      A2<-AA11[1:(3*n1),((3*n1)+1):(3*(n1+n2))]
      A3<-t(A2)
      A4<-AA11[((3*n1)+1):(3*(n1+n2)),((3*n1)+1):(3*(n1+n2))]
      d1<-apply(A1,2,sum)
      m1<-sum(d1)
      M1<-A1-(d1%*%t(d1))/m1
      row<-apply(A2,1,sum) ##X^Y
      col<-apply(A2,2,sum) ##Y^X 
      m2<-sum(row)
      M2<-A2-(row%*%t(col))/m2
      M3<-t(M2)
      diag(A4)=0
      d4<-apply(A4,2,sum)
      m4<-sum(d4)
      M4<-A4-(d4%*%t(d4))/m4
    }
    else{
      print("networks are not the same size")
    }
  M<- rbind(cbind(M1/m1,M2/m2),cbind(M3/m2,M4/m4))
  M
}

  
#####Method 4 in the paper ########
calculate_MMat5<-function(size,n,n1,n2){                           #this function calculates the modularity matrix of Method 4 in th paper. Here size is the number of nodes in the network and n is the number of snapshots.
  M1<-matrix(0,3*n1,3*n1)
  M2<-matrix(0,3*n2,3*n2)
  sum1<-sum2<-0
  for(i in 1:n){
    A<-read.csv(paste("A",i,".csv",sep=""),header=F)
    A<-as.matrix(A)
    if(dim(A)[1]==size & dim(A)[2]==size){
      G<-graph.adjacency(A,mode="max")
      A<-get.adjacency(G,type="both",sparse=F)
      G<-graph.adjacency(A[1:(3*n1),1:(3*n1)],mode="undirected")
      d<-degree(G)
      f<-sum(d)
      M1<-M1+A[1:(3*n1),1:(3*n1)]-(d%*%t(d))/f
      sum1<-sum1+sum(A[1:(3*n1),1:(3*n1)])
      G<-graph.adjacency(A[(3*n1+1):(3*(n1+n2)),(3*n1+1):(3*(n1+n2))],mode="undirected")
      d<-degree(G)
      f<-sum(d)
      M2<-M2+A[(3*n1+1):(3*(n1+n2)),(3*n1+1):(3*(n1+n2))]-(d%*%t(d))/f
      sum2<-sum2+sum(A[(3*n1+1):(3*(n1+n2)),(3*n1+1):(3*(n1+n2))])
    }
    else{
      print("networks are not the same size")
    }
  }
list(M1=M1,M2=M2,sum1=sum1,sum2=sum2)
}






##This is the code for calling the louvain algorithm
##In the second line, please modify the path as "the directory of the downloaded 'Rtoolbox' file"
code<-c(   
  "newFolder='/Users/zhangmaoyu/博士文件/Emma/JCGS_DHNET/Rtoolbox';",               #change this to the path of the downloaded 'Rtoolbox' file
  "cd(newFolder)",
  "M=csvread('MMatrix.csv',1,0);",
  "cd(newFolder)",
  "cd('./GenLouvain2.0')",
  "[s0,q0]=genlouvain(M,10000,0);",
  "for i=1:100",                                                #apply the louvain method 100 times and output the one with the largest modularity value
  "[s,q]=genlouvain(M,10000,0);",
  "if q>q0",
  "q0=q;",
  "s0=s;",
  "end",
  "end",
  "cd(newFolder)",
  "csvwrite('membership.csv',s0)",
  "csvwrite('modularity.csv',full(q0))"
)



#######example########
### the directory needs to be specified at line 186 and 209
####generate data####
for(i in 1:20){
  A<-generateA(n1=200,n2=100,p1=0.5,p2=0.6,p3=0.3,r1=0,r2=0,r3=0.1)
  write.table(A,paste("A",i,".csv",sep=""),sep=",",row.names=FALSE,col.names=FALSE)	
}

######Proposed method#####
r11<-c()###save the NMI of the first type node estimated by the proposed method
r12<-c()###save the NMI of the second type node estimated by the proposed method
MM<-calculate_MMat(size=900,n=20,n1=200,n2=100)                                          
write.csv(MM,"MMatrix.csv",row.names=F)
run_matlab_code(code,verbose = FALSE)
membership<-t(read.csv("membership.csv",header=F))
r11<-c(r11,compare(membership[1:600],c(rep(1,200),rep(2,200),rep(3,200)),method="nmi"))
r12<-c(r12,compare(membership[601:900],c(rep(1,100),rep(2,100),rep(3,100)),method="nmi"))
modularity<-as.numeric(read.csv("modularity.csv",header=F))

#########Method 1#########
r21<-c()###save the NMI of the first type node estimated by Method 1 in the paper
r22<-c()###save the NMI of the second type node estimated by  Method 1 in the paper
MM<-calculate_MMat2(size=900,n=20)                                    
write.csv(MM$M,"MMatrix.csv",row.names=F)
run_matlab_code(code,verbose = FALSE)
membership<-t(read.csv("membership.csv",header=F))
r21<-c(r21,compare(membership[1:600],c(rep(1,200),rep(2,200),rep(3,200)),method="nmi"))
r22<-c(r22,compare(membership[601:900],c(rep(1,100),rep(2,100),rep(3,100)),method="nmi"))
modularity2<-as.numeric(read.csv("modularity.csv",header=F))/MM$sum
  
#########Method 2############
r31<-c()###save the NMI of the first type node estimated by Method 2 in the paper
r32<-c()###save the NMI of the second type node estimated by Method 2 in the paper
MM<-calculate_MMat3(size=900,n=20,n1=200,n2=100)
write.csv(MM,"MMatrix.csv",row.names=F)
run_matlab_code(code,verbose = FALSE)
membership<-t(read.csv("membership.csv",header=F))
r31<-c(r31,compare(membership[1:600],c(rep(1,200),rep(2,200),rep(3,200)),method="nmi"))
r32<-c(r32,compare(membership[601:900],c(rep(1,100),rep(2,100),rep(3,100)),method="nmi"))
modularity3<-as.numeric(read.csv("modularity.csv",header=F))

#########Method 3###########
r41<-c()###save the NMI of the first type node estimated by Method 3 in the paper
r42<-c()###save the NMI of the second type node estimated by Method 3 in the paper
MM<-calculate_MMat4(size=900,n=20,n1=200,n2=100)                                             #set this to the downloaded 'Rtoolbox' file
write.csv(MM,"MMatrix.csv",row.names=F)
run_matlab_code(code,verbose = FALSE)
membership<-t(read.csv("membership.csv",header=F))
r41<-c(r41,compare(membership[1:600],c(rep(1,200),rep(2,200),rep(3,200)),method="nmi"))
r42<-c(r42,compare(membership[601:900],c(rep(1,100),rep(2,100),rep(3,100)),method="nmi"))
modularity4<-as.numeric(read.csv("modularity.csv",header=F))

############Method 4########
r51<-c()###save the NMI of the first type node estimated by Method 4 in the paper
r52<-c()###save the NMI of the second type node estimated by Method 4 in the paper
MM<-calculate_MMat5(size=900,n=20,n1=200,n2=100)
write.csv(MM$M1,"MMatrix.csv",row.names=F)
run_matlab_code(code,verbose = FALSE)
membership<-t(read.csv("membership.csv",header=F))
r51<-c(r51,compare(membership[1:600],c(rep(1,200),rep(2,200),rep(3,200)),method="nmi"))
modularity51<-as.numeric(read.csv("modularity.csv",header=F))/MM$sum1
write.csv(MM$M2,"MMatrix.csv",row.names=F)
run_matlab_code(code,verbose = FALSE)
membership<-t(read.csv("membership.csv",header=F))
r52<-c(r52,compare(membership[1:300],c(rep(1,100),rep(2,100),rep(3,100)),method="nmi"))
modularity52<-as.numeric(read.csv("modularity.csv",header=F))/MM$sum2

###list the results###
list(r11=r11,r12=r12,r21=r21,r22=r22,r31=r31,r32=r32,r41=r41,r42=r42,r51=r51,r52=r52)

