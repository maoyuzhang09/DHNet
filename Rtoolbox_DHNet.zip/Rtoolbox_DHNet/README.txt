README - R Tool for Identifying Common Functional Modules
April 2023


The downloaded folder 'Rtoolbox' has three components:


data_example: this folder contains an example dataset. The code used to generate the example dataset is also included in this folder under name ‘generateBlock.R’; If you want to reproduce some simulation results in the paper, you only need to modify the corresponding parameter values introduced in simulation section of the paper.

‘Code for DHNet.R’: this file contains scripts for finding common community structure by the proposed method and the other 4 methods compared in the paper. The output has two parts; one part is the community membership and the other part is the maximum modularity value. Examples for the 5 methods are included at the end of the file, you can reproduce the simulation results in the paper by repeating it several times.


###Note that there are some places in the 'Code for DHNet.R' file where you need to modify the directory, please follow the comments to modify the corresponding directory before running the code.



GenLouvain2.0: this folder contains the Matlab package for efficient Louvain method application developed by Jutla et al. (2011-2014). Please refer to:   
Inderjit S. Jutla, Lucas G. S. Jeub, and Peter J. Mucha, "A generalized Louvain method for community detection implemented in MATLAB," http://netwiki.amath.unc.edu/GenLouvain (2011-2014).